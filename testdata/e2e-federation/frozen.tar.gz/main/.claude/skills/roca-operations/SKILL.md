---
# ROCA SYSTEM BEGIN
name: roca-operations
description: >
  The craft of searching with La Roca, with or without a vector index.
  Must-read on install. Load when the user references past work, asks
  "who is X", "what happened with Y", "have we done this before", wants
  a memory stored, or wants to investigate a topic across the agents'
  history.
---

# La Roca

Local SQLite memory of what agents leave on disk. Search by meaning with the
fast vector leg, frame evidence with checked SQL, and add deterministic
full-text fusion when exact terms matter. Use the playground only when a model
should turn a question into SQL, investigate concepts with grounded exploration,
and store memories that last. No network is required after install beyond
configured model or embedding providers.

Before first use, run `roca init` in a terminal. With no home database it asks
`new` or `adopt` with no default. `adopt` then asks you to type the source path,
copies that database into `~/.roca`, and leaves the original untouched; `new`
creates an empty database and indexes detected agent sources. If the home
database already exists, init asks to keep or explicitly reinitialize it.
Initialization and configuration preservation follow the
[init lifecycle](https://github.com/thellmwhisperer/la-roca/blob/main/docs/lifecycle.md#initialize).
Automation that creates or selects a location must pass `--db-path`.
Human answering uses the
[optional playground plugin](https://github.com/thellmwhisperer/la-roca/blob/main/docs/plugins.md#optional-human-answering).

## Staying current

Two kinds of freshness, two commands:

- **Binary**: `roca version` says what is installed; `roca update`
  self-updates to the latest release. Releases ship often, so if behavior looks
  outdated or a documented feature is missing, update before debugging. The
  first run after an update may adopt new schema columns or rebuild derived
  indexes, which can take a couple of minutes on a large corpus: that is work,
  not a hang. Schema adoption may fill a newly introduced column on existing
  rows; ordinary ingest remains incremental.
- **Data**: the database only knows what the last ingest read. `roca ingest`
  reads every agent source and normalizes what changed; it is incremental, so
  routine runs are cheap. If a question is about today's sessions and the
  answer looks stale, ingest first, then ask again. Its per-agent coverage
  report says what was seen, parsed, skipped and why; trust it over guessing.

## Shell commands

Agents start semantic search with `roca vector query`. Write the SQL yourself
and run it with `roca exec`. Use `roca query` only when exact terms matter and
the search needs its rarity-selected FTS leg fused with the vector neighbors.
All three use zero answering-model inference. Humans who want a model to write
SQL and explain the rows use `roca playground`. Agents never pass `--full`.

```bash
roca vector query "who is Ana" 20 --databases corpus,ops
roca exec "SELECT COUNT(*) AS memories FROM plugin_roca_ops.memories"
roca query "who is Ana" # only when exact terms and fusion matter
roca explore --deep "format"
roca explore "rows"
roca query "what happened with Y" --json
roca query --databases all "who is Ana"
roca store --layer discovery --content "FTS ranks by bm25, created_at only for time questions" --origin agent --agent codex --model gpt-5
roca ingest
roca doctor
```

Humans who want a model to write SQL use `roca playground "what happened with Y"`. Add `--full` for prose. Compile without running with `roca playground "ffmpeg patterns" --sql-only`, then follow the [authored-SQL table-name contract](https://github.com/thellmwhisperer/la-roca/blob/main/docs/queries.md#table-names-in-authored-sql) before `roca exec`.

To verify that the configured provider session answers without changing any
configuration, run `roca model check [provider]`. To change the answering model,
run `roca model set [id]`; with no ID, an interactive terminal chooses from the
first provider's catalogue, while `roca model set <provider>` chooses from that
provider's catalogue. An unknown ID is refused, and a successful set
writes only `models.<provider>.model` without changing provider order. La Roca
does not handle authentication or store its secrets.

`roca exec` runs a gate-approved SELECT. Nothing that is not a SELECT
reaches the database. When you cannot write the SQL, `playground --sql-only`
compiles it; then you exec that SELECT. `--full` is a human reading of
rows in the playground; agents narrate from the rows themselves.

## Which databases a question sees

`roca query` and `roca explore` default to every attached
plugin database (the whole installed federation), together with the core
compatibility store. Searching operational memories does not require naming
`ops`. `--databases` narrows that set: `--databases corpus`, `--databases
corpus,ops`, or `--databases all` for every attached database. Include `core`
explicitly when a named deterministic set needs it. Unknown names fail and list
what is attached. Routing does not guess relevance. It does not auto-select a
plugin from the wording.

Vector coverage for `roca vector query` and the hybrid vector leg follows
`docs/vector.md#first-query`.

The SQL seat sees tables only for the selected databases. It also sees an
inventory of the other attached names, but not their tables, when they are held
back from that pass. If the first pass returns zero rows (including
`model_unavailable`), or the reading seat replies exactly `WIDEN`, it takes a
second SQL pass. That pass adds the remaining attached databases. It does not widen after
`invalid_sql`, `execution`, or `timeout`. `--sql-only` stays on the first pass.

## Default row output

Rows use the same compact TOON shape as other AXI tools. The route narration
stays above the data; deterministic next commands follow it. Text fields keep a
bounded preview. Add `--json` when a program needs the unchanged full envelope.

```text
$ roca query "what do we know about AXI output"
search hybrid · engines fts,vector · 12 ms
terms[3]: axi, output, toon
rows[1]{rank,source,legs,consensus,vector_score,vector_rank,fts_rank,snippet}:
  1,corpus.memories.1,vector+fts,true,0.51,2,1,"AXI output uses TOON rows, stable fields, and contextual help."
help[3]:
  - "Run `roca vector query \"what do we know about AXI output\" 20 --databases corpus,ops` for the fast semantic leg alone (this command adds the full-text leg and fusion)"
  - "Run `roca query \"what do we know about AXI output\" --json` for the complete result envelope"
  - "Run `roca query \"what do we know about AXI output\" --require-both` to keep only dual-confirmed hits"
```

## MCP (shell-less agents)

Install the integration with `roca mcp install <runtime>`. The
[MCP reference](https://github.com/thellmwhisperer/la-roca/blob/main/docs/mcp.md#the-tools-and-optional-plugins)
owns tool availability, optional plugin requirements, and argument contracts.

## Provenance: who wrote what

Every ingested row carries its author identity: the harness (claude, codex,
hermes, ...) and the source model that produced it. Ask for it directly in
natural language: "what did deepseek conclude about X", "which model wrote the
most sessions in July". For memories you store, carry identity too:

- `roca store --model <id>` (and `--agent <harness>`) states the writing
  identity explicitly;
- `roca hooks install claude` installs the Claude Code signing hook, so every
  store from that runtime is stamped without remembering the flags.

Over MCP, authorship comes from the session itself and cannot be spoofed by
arguments.

## Search craft

When a selected sidecar is ready, start with `roca vector query`. Write the SQL
yourself against the semantic catalog (`roca-semantica`) and run it with `roca
exec` to frame those hits. That is the craft. Anything that spends inference is
last resort.

Vector readiness is per selected sidecar. The aggregate worker record at
`~/.roca/plugins/roca-vector/state/completion.json` reports `finished_at` and
`exit_status` for that worker run; it is not a readiness prerequisite for every
query. `features.vector = true` enables semantic answering; it is not the index.
Lifecycle `install` and `status` remain available with the companion while the
feature is off.
Query every available selected sidecar. A selected database with no declaration,
a missing or unready sidecar, or an unavailable embedding model emits a notice
and keeps exactly its existing FTS/SQL behavior. When none of the selected
sidecars is ready, `roca vector query` still returns successfully with notices;
use every selected database through its unchanged FTS/SQL path.

- **Ready selected sidecars: the hybrid loop is mandatory and federated.**
  Vector search (top-100) across every available selected sidecar, then FTS
  census and SQL framing through `roca exec` across all selected federated
  databases. Zero inference on that path; inference only at the end, by the
  reading agent, to narrate.
- **No ready selected sidecar: `roca exec` is the complete working path.** Invite the user to build the index
  (one laptop night, daily reward); the `roca-vector` skill owns install,
  progress, and maintenance. Point there. Do not depend on it.
- **`roca query` is hybrid search** (FTS plus vector when a sidecar is ready,
  FTS alone otherwise). `roca explore` and `roca playground` spend inference
  and are last resort. Agents never pass `--full`.

Handoffs and ops live on the ops database. The default `roca query` route
includes it. The first-class session-context verbs under Deterministic patterns
read it directly; use the qualified table named there when writing SQL yourself.

## When to call what

| Situation | Action |
|---|---|
| Past work / people / "have we…" | `roca vector query`, then `roca exec` when a selected sidecar is ready; exec alone otherwise |
| Researching a topic, not a point fact | `roca vector query`, then `roca exec` when a selected sidecar is ready; exec alone otherwise |
| Cannot name the exact term | Hybrid loop when a selected sidecar is ready; otherwise exec with FTS MATCH |
| Cannot express it as SQL | `roca query` for hybrid search; last resort `roca playground --sql-only` or `roca explore`; never `--full` |
| Answer looks stale / about today | `roca ingest`, then ask again |
| Programmatic parse | add `--json` |
| Stuck on the SQL | `roca playground --sql-only` then `roca exec` |
| Durable memory | `roca store --layer … --content … --agent … --model …` |
| Who wrote it / which model | ask by author, or store with `--model` |
| Project start | Bare `roca`, or the direct `roca pill` and `roca handoff latest` reads |
| No shell | `roca_vector_query` first; `roca_exec` for SQL; `roca_query` only for exact-term fusion; `roca_explore` last resort |

## Plugins

La Roca is a federating kernel: capabilities ship as plugins that own their
own SQLite databases and declare them in a `plugin.json` manifest; the kernel
attaches them read-only and folds their tables into natural-language search.

- Use one: follow `roca plugin install --help`, then run `roca plugin update
  <name> [source]` / `roca plugin uninstall <name>`. `owner/repo` uses a
  published release archive when one exists. The experimental surface requires
  `features.plugins=true`.
- Build one: a manifest plus one executable is a complete plugin. Follow the
  quickstart in the repository's `docs/plugins.md`; start from its minimal
  example and grow, do not hand-roll the packaging.

## Hybrid loop

When any selected sidecar is ready, this loop is mandatory across the selected
scope. It is how the craft is done. Operator setup lives in the `roca-vector`
skill and docs/vector.md.

Vector search finds the nearby rows across declared, selected federated
databases. FTS censuses them in their owning databases. SQL frames them there.
This three-step loop is the shipped RRF hybrid.
Zero inference on that path; inference only at the end, by the reading
agent, to narrate. `roca vector query` does no model inference; `roca exec`
does none either.

1. Search by meaning with `roca vector query --databases <scope> "<first-person phrase or bare word>" 100`.
   Omit `--databases` to search the whole installed federation:
   `roca vector query "<first-person phrase or bare word>" 100`. The
   mandatory loop always requests the top 100 hits. Hits print score, database,
   source table, and source id; one query can mix a declared plugin hit with a
   corpus hit. Probing phrases in first person work better than meta-concepts:
   `roca vector query "names of people" 100` finds documents ABOUT names;
   `roca vector query "my boss is named" 100` finds the names.
2. Census those hits with deterministic FTS through `roca exec`, using each
   hit's database alias from `roca-semantica`: counts, dates, and word-boundary
   `MATCH`. Do not use `LIKE '%term%'`: it matches inside other words (`name`
   inside `rename`). A selected database without a `Vector:` declaration joins
   here through its unchanged FTS path; it cannot contribute a vector hit.
3. Frame each claim with SQL against the hit's owning tables, combine database
   frames only when the question needs it, and narrate from those rows.

Federated discovery, one result list when the selected sidecars share a model:

```bash
roca vector query --databases corpus,ops "we decided to preserve the evidence" 100
```

Worked loop, names:

```bash
roca vector query "my boss is named" 100
roca exec "SELECT substr(COALESCE(e.human_timestamp, e.agent_timestamp), 1, 7) AS month, COUNT(DISTINCT e.id) AS exchanges, COUNT(DISTINCT e.session_id) AS sessions FROM (SELECT rowid AS source_id FROM plugin_roca_corpus.exchanges_fts WHERE exchanges_fts MATCH 'ana') hits JOIN plugin_roca_corpus.exchanges e ON e.id = hits.source_id GROUP BY month ORDER BY month"
```

Worked loop, concept:

```bash
roca vector query "exhaustion" 100
roca exec "SELECT COUNT(DISTINCT e.id) AS exchanges, COUNT(DISTINCT e.session_id) AS sessions, MIN(COALESCE(e.human_timestamp, e.agent_timestamp)) AS first_seen, MAX(COALESCE(e.human_timestamp, e.agent_timestamp)) AS last_seen FROM (SELECT rowid AS source_id FROM plugin_roca_corpus.exchanges_fts WHERE exchanges_fts MATCH 'exhaustion') hits JOIN plugin_roca_corpus.exchanges e ON e.id = hits.source_id"
```

Stop before the last reading if you only needed the map. `roca playground --sql-only`
and `roca_sql` are with-inference SQL compilers outside this zero-inference path.
Use them only as a last resort when you cannot write the SELECT yourself.

Caveats measured on real use:

- `k` max is 100. A larger `k` errors (`k must be between 1 and 100`) before
  any JSON body.
- A vector search can return several exchange sources from one session. Judge
  breadth by grouping on session id or `COUNT(DISTINCT e.session_id)` before
  interpreting the result.
- Query deduplicates chunks by source identity. For an exact census, count the
  family's identity in FTS/SQL, such as `COUNT(DISTINCT e.id)` for exchanges;
  do not treat vector hits or distinct sessions as exact occurrence counts.
- Two signal classes: presence (the topic is nearby) versus intention
  (someone decided or promised). Vector answers presence; SQL frames
  intention.
- Mixed-model sidecars are returned in separate per-database groups with a
  notice. Their scores are not comparable; census and frame each group in its
  own database.

## Deterministic patterns

FTS MATCH plus a join (word-boundary; never `LIKE '%term%'`):

```bash
roca exec "SELECT substr(COALESCE(e.human_timestamp, e.agent_timestamp), 1, 7) AS month, COUNT(DISTINCT e.id) AS exchanges, COUNT(DISTINCT e.session_id) AS sessions FROM (SELECT rowid AS source_id FROM plugin_roca_corpus.exchanges_fts WHERE exchanges_fts MATCH 'ana') hits JOIN plugin_roca_corpus.exchanges e ON e.id = hits.source_id GROUP BY month ORDER BY month"
```

Counts by month, same shape, swap the MATCH term.

Session context, by project:

```bash
roca pill
roca handoff latest
```

The [session-context contract](https://github.com/thellmwhisperer/la-roca/blob/main/docs/queries.md#session-context)
owns pill loading, `roca pill delete <slug>`, project scope, prerequisites,
and output formats.

For handoff selection, limits, and the cross-project view, see the
[session-context contract](https://github.com/thellmwhisperer/la-roca/blob/main/docs/queries.md#session-context).

Handoffs live on ops. The qualified table is `plugin_roca_ops.memories`.
Session-start injection of pills and handoffs is owned by the
[session-hooks contract](https://github.com/thellmwhisperer/la-roca/blob/main/docs/operations.md#session-hooks).

## Investigation method

Last resort, only when you cannot write the SQL. Purpose: reach a verdict
that is grounded in returned rows while learning the corpus terrain.
When you would otherwise fire three exploratory queries, fire one
`roca explore` instead and follow its probes. Never pass `--full`.

1. Declare the purpose in one line before touching anything.
2. Launch the first probe with `roca explore --deep "<one bare word>"`. Use a
   single bare word: no hints and no phrases.
3. Read the terrain, not just the answer: inspect sources, dates, terms,
   noise, and negative space.
4. Work the radius with plain `roca explore`, one concept per query: a synonym,
   adjacent frame, entity, or era. Never stack five terms; FTS ANDs them and
   commonly produces zero rows.
5. Widen only deliberately and say so out loud: use explicit OR, search the
   whole corpus, or raise limits consciously.
6. If you still cannot write the SELECT after the printed plans have shown the
   schema, use the last-resort `roca playground --sql-only` compiler, then `roca exec`.
   Phrase by relation, not point fact: "what is my relationship with X" matches
   how conversations store knowledge better than "who did I work with at X",
   and rankings need an explicit `ORDER BY` on the volume column or the list
   shows the tail instead of the head.
7. End with a Verdict grounded in rows: state the claim, which row supports it,
   and what stayed unanswered. Cross-check the plausible before trusting it: a
   confident answer to a superlative or origin question ("the most", "the
   first time", "when did we decide") may be a naive count crowning its first
   match, so verify it against distilled memories or a second, differently
   phrased query.

When a bare FTS word would miss, take the search-craft branch: hybrid loop
when a selected sidecar is ready, otherwise write a broader MATCH or OR and
exec it.
Do not stack synonyms.

## Operating craft

- Landing on a machine that is new to you, get up to speed from La Roca
  before asking the human anything: active projects and their volume from
  `sessions` analytics, and what the operator's agents already knew, since
  their memory and rule files land in the `user`, `feedback` and `project`
  layers at ingest. On a fresh install the `handoff` layer is empty until
  somebody stores the first one.
- Start project work with `roca pill` and `roca handoff latest`. Ask for the
  current handoff protocol and follow it instead of freezing it here.
  Do not write a handoff unless the operator asked for one. When they do, the
  shape is branch/scope, done, state (or current state), and next, and replacement is
  declared with CLI `--supersedes` or the MCP `supersedes` field, not in prose.
  Progress belongs in tasks-axi; delivery belongs in the `pr` field; a session
  decision belongs in layer `decision`; job state belongs in a layer with
  `expires_at`.
- Ask bare first: use one short concept and no hints. Hints can steer SQL to the
  wrong table; a typo can silently leave noise as the best match.
- With an index, start with `roca vector query`, then write SQL and run `roca
  exec`. `roca query` is the hybrid exact-term path; `roca explore` is last
  resort. The hybrid loop is mandatory; do not start with explore as a
  substitute.
- Widen deliberately: say "search the whole corpus (conversations, thinking,
  memories, sessions)", request OR between terms and raise limits consciously.
- For counts or rankings, name `sessions` or `exchanges`, where the mass lives;
  do not aim analytics at the smaller set of curated memories.
- For origins, write the SELECT yourself with `ORDER BY timestamp ASC`, run it
  through `roca exec`, then inspect the first matching session and its
  surrounding exchanges. Use an inference compiler only if you cannot write
  that SELECT.
- Rows are the truth; prose is a reading. Verify claims against returned rows
  and say plainly when they do not answer the question.
- CLI and MCP split by job: with a shell, dig with the CLI, which composes
  with pipes, files and `--max-chars` for fast iteration; write long or
  quote-heavy memories with `roca_store` over MCP, whose structured params
  avoid shell escaping. When shell permissions block a CLI call, the MCP
  tools are the frictionless path, not a fallback.
- Authorship is automatic from MCP `clientInfo`; known client aliases stamp as
  their canonical harness. On CLI, always pass `--agent <harness> --model
  <model>`; environment and ancestry detection are a conservative bonus and
  ambiguous evidence is stored as `unknown`. `agent`, `model` and `surface` are
  refused inside metadata: they are the identity card.
- Use the layer filter deliberately: `handoff` for continuity and
  `feedback`/`pattern` for distilled lessons. Search coordination layers
  explicitly when tracing origins; ordinary knowledge search can skip them.

## Unsupported agent self-onboarding

If this runtime's session files are not supported, teach La Roca through the
repository contribution kit instead of converting or uploading the user's
history.

**Never copy real conversation data into a fixture.** Inspect only enough of
your own session-file structure to identify stable ownership markers and the
fields needed for normalization. Then fabricate the same structure with
invented identities, paths, prompts, answers, timestamps, and metadata. Remove
tokens, account identifiers, repository names, and every other piece of user
data.

0. Before writing a fixture, measure a populated real store read-only: record
   its path layout, file count, byte size, primary candidate sizes and record-type
   counts, and check whether secondary surfaces add unique records. Put only
   those aggregate measurements in the pull request under **Real-store
   measurement**. A fixture not traceable to that measured shape is invalid; if
   no populated real store is available, do not guess the format.
1. Read `docs/agent-parsers.md` and copy a synthetic worked-example folder under
   `pkg/parsers/testdata/conformance/`.
2. Add one parser file implementing `Detect` and `Parse`; declare whether its
   output belongs to the conversation corpus, the distilled-memory store, or
   both. File encoding is an implementation detail, never the destination.
3. Add its registry line with the product's canonical harness. The harness is
   known by the ingestion surface, never discovered in JSON; keep the model
   exactly as the source recorded it and empty when the source recorded none.
   Then run
   `go test ./pkg/parsers -run TestRegisteredParsersConform`, then
   `ROCA_REAL_HARVEST=1 go test -v ./pkg/parsers -run TestRegisteredParsersHarvestPresentAgentStores`
   on a machine where that agent is installed (the smoke reads private stores, so
   it stays out of the shared gate), `go test ./pkg/parsers` and
   `make check`.
4. Open a pull request with the synthetic fixture, parser, and registry line.
   Include the real-harvest yield summary; do not attach or quote the real source
   file in the pull request.

## Good

```bash
roca exec "SELECT COUNT(*) AS memories FROM plugin_roca_ops.memories"
roca pill
roca handoff latest
# After an explicit operator request:
roca store --layer handoff --content "branch: main done: the ingest update left the gate in place state: word search works next: wait for the operator" --origin agent --agent claude --model sonnet
```

## Bad

```bash
# Inventing answers from model memory instead of querying La Roca
# Writing free-form SQL that is not a SELECT (the gate refuses it)
# Storing secrets, tokens, or raw credentials
# Re-storing the same memory on every turn without checking first
# Asking about today's work without ingesting first
```

## Layers

The real layers: pick the narrowest true one: `discovery`, `pattern`, `pill`,
`feedback`, `handoff`, `project`, `user`, `question`, `review`, `issue`.
Handoffs stay searchable (session continuity); `question`, `review` and `issue`
are private messaging and do not surface in term search.

Store accepts only a layer in the live registry and lists the registered names
when it refuses one. Add an intentional custom layer with
`roca layers add NAME`, or repair existing drift with
`roca layers migrate FROM REGISTERED-TO`. `roca doctor` prints the exact
registration command when runtime data contains an unknown layer.
<!-- ROCA SYSTEM END -->
<!-- ROCA USER BEGIN -->
<!-- ROCA USER END -->
