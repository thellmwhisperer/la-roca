---
# ROCA SYSTEM BEGIN
name: roca
description: >
  What La Roca is. Must-read on install. Load to learn how to init, invite
  the user to the semantic layer, and make the first search land.
---

# La Roca is an AI agent memory

If your user pointed you here to **install and use** La Roca, this section is
yours. If you are here to develop La Roca itself, skip to the
[contributor notes](#contributor-notes) below.

You are about to give your user a memory of everything their agents ever
did on this machine: every session, decision, fix, and note that you and
your sibling agents wrote to disk and forgot. After the steps below, you
can answer questions about that history with proof.

## Step one: install, initialize, and learn the first search

`roca init` creates the database, reads the agent history already on this
machine, writes the skills into the runtimes it finds, and does not return
until word search works. The last thing it does is prove it: it takes a word
out of your user's own history and asks the index for it.

After init, bare `roca` opens the laboratory menu and teaches the next commands
in order: fast semantic search, checked SQL, then hybrid search when exact terms
matter. If the optional semantic index is still building, word search and SQL
already work.

```sh
curl -fsSL https://raw.githubusercontent.com/thellmwhisperer/la-roca/main/install.sh | sh
roca init      # imports agent history; no answering model required
roca           # project handoffs, active pills, and vector-first help
roca vector query "what did we decide about <something your user cares about>" 20 --databases corpus,ops
```

`roca init` runs the first ingest. Later, `roca ingest` picks up whatever is
new. A growing session file appends new exchanges; it does not rewrite rows
that already landed. `roca compact` rewrites an older corpus database onto
one current row per fact and VACUUMs. Version tables keep digests, not a
second copy of the text. Archive bookkeeping that duplicated current rows
is emptied. `roca query` is hybrid search with labeled evidence; `roca exec`
is the checked SELECT seat.

## Read the installed skills, now, not later

The skills ARE the semantic layer: the memory layers, the tables, and worked
examples of how to query them. That map is static; it does not drift as data
grows, and it regenerates automatically when the installed plugin set
changes. Reading it is the difference between composing good SQL and
guessing:

This ships the operating craft plus `roca-semantica`, the generated catalog
of every installed database's tables and example questions. Read both
before your first real search. If you cannot write skills into your
runtime, `roca mcp install <runtime>` exposes the same operations as tools.

## Step two (optional): add vector search

Do not make the first working answer depend on vectors. Full-text search works
first. During interactive init, after word search works, La Roca asks once for
permission to find history by meaning and to download the model it needs. A
yes records the decision and starts the background build. The companion's
`install` and `status` lifecycle commands remain available while the feature is
off; its answering verbs require `vector = true`.

If they decline during init and choose semantic search later, set
`vector = true` under `[features]` in `~/.roca/config.toml` (or in
`config.toml` next to
the database selected with `--db-path`), then start the build:

```sh
roca vector install
```

`roca vector status` reports per-database sidecar facts. A number that cannot
be read is unknown, never 0:

```sh
roca vector status
```

A pass that stopped partway is not an empty product: what it already read
answers, and word search answers for the rest. If this machine cannot embed at
all, init says so and gives one next step; it is never a wall. Full contract:
docs/vector.md.

## How to search well

Read `roca-operations` before your first real search. When the vector index is
ready, start with `roca vector query`, then frame the evidence with SQL from the
semantic catalog through `roca exec`. Use `roca query` when exact terms matter
and you need the full-text leg fused in. Anything that spends inference is last
resort: `roca playground` and `roca explore`, supplied by the optional
[roca-playground plugin](docs/plugins.md#optional-human-answering). `--full` is
for humans; agents do not use it.

A fresh install has no vector index. Exec still works. When the index exists,
that same skill makes the hybrid loop mandatory: vector search finds the
nearby rows, full text counts them, SQL frames them through exec.
Zero inference on that path; inference only at the end, to narrate.

The `roca-vector` skill owns the deep pass: starting it, watching it, and
keeping it fresh. Invite the user (one laptop night, daily reward). Do not
wait for the index to search well.

## Make the first answer land

You know this user: their project, what matters to them, what they keep
re-explaining to every new session. When the first ingest finishes, do not
wait to be asked. Pick one question you know they will appreciate and run
it: a decision they half-remember, the first time a bug appeared, what
they were working on a year ago today. Show them their own history
answering back.

This tool was built for agents to do great work with. Enjoy it, and make
the first impact count.

## Contributor notes

Build, test, and architecture notes live in [CONTRIBUTING.md](CONTRIBUTING.md)
and [project memory](docs/project-memory.md).

### Adjacent features

La Roca is a light binary that queries local SQLite, attaches other databases,
answers by FTS or by vectors with one embedding model, plus plugins. Anything
else is adjacent until proven core.

- Every brief states what NOT to build and the real data size.
- A reviewer demand must state its cost (bytes, seconds, lines) or it cannot
  block.
- No new subsystem outside the ticket's scope.
- Read-only means SQLite `mode=ro`, never a copy.
- Reuse the OS, SQLite and the standard library before writing an equivalent.

The [adjacent-feature registry](.slop/dragons/README.md) owns dragon records,
removal rules, and cost-check guidance.

## Maintaining this file

Keep this file for knowledge useful to almost every future agent session in this project.
Do not repeat what the codebase already shows; point to the authoritative file or command instead.
Prefer rewriting or pruning existing entries over appending new ones.
When updating this file, preserve this bar for all agents and keep entries concise.
<!-- ROCA SYSTEM END -->
<!-- ROCA USER BEGIN -->
<!-- ROCA USER END -->
