<!-- ROCA SYSTEM BEGIN -->
## La Roca — local semantic memory
La Roca contains local session history, curated memories, handoffs, decisions, and tool traces from your agents.
when to query: at session start, before repeating research, and whenever prior context or a decision may exist.
With a shell, use `roca query "<natural question>"`; preserve durable context with `roca store --agent <harness> --model <model>` so CLI authorship is explicit.
Search = `roca query`; checked SQL = `roca exec`.
The optional playground plugin provides human answers with `roca playground --full` and investigations with `roca explore`.
Without a shell, use `roca_query`, `roca_exec`, and `roca_store`; `roca_explore` requires the plugin.
Authorship is automatic over MCP; CLI detection is conservative, so pass --agent and --model.
`roca init` prepares search and preserves existing configuration. The optional plugin uses its [models] settings.
La Roca never edits agent instruction files; a human chooses where to paste this block.
<!-- ROCA SYSTEM END -->
<!-- ROCA USER BEGIN -->
<!-- ROCA USER END -->
