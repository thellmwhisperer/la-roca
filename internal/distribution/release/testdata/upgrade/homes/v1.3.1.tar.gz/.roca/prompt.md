## La Roca — local semantic memory
La Roca contains local session history, curated memories, handoffs, decisions, and tool traces from your agents.
when to query: at session start, before repeating research, and whenever prior context or a decision may exist.
With a shell, use `roca query "<natural question>"`; preserve durable context with `roca store`.
Data = `roca query`; human reading = `roca query --full`; raw SQL = `roca exec`.
Without a shell, use the MCP equivalents: `roca_query` and `roca_store`.
On first bootstrap, `roca init` asks new or adopt; adoption uses only the source path the user types.
La Roca never edits agent instruction files; a human chooses where to paste this block.
