<!-- ROCA SYSTEM BEGIN -->
## La Roca — local semantic memory
La Roca contains local session history, curated memories, handoffs, decisions, and tool traces from your agents.
when to query: at session start, before repeating research, and whenever prior context or a decision may exist.
With a shell, use `roca query "<natural question>"`; preserve durable context with `roca store --agent <harness> --model <model>` so CLI authorship is explicit.
Data = `roca query`; human reading = `roca query --full`; raw SQL = `roca exec`.
Investigations start with `roca explore --deep "<one bare word>"`, then plain `roca explore` radius probes.
Without a shell, use the MCP equivalents: `roca_query`, `roca_explore`, and `roca_store`.
Authorship is automatic over MCP; CLI detection is conservative, so pass --agent and --model.
On first bootstrap, `roca init` asks new or adopt, then chooses the answering model before its harness.
La Roca never edits agent instruction files; a human chooses where to paste this block.
<!-- ROCA SYSTEM END -->
<!-- ROCA USER BEGIN -->
<!-- ROCA USER END -->
